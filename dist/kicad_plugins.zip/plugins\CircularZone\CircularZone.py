from math import *
import pcbnew
from .CircularZoneDlg import CircularZoneDlg
import wx
import os


class CircularZone(pcbnew.ActionPlugin):

    def defaults(self):
        self.name = "圆形区域\n禁止布线区生成器"
        self.category = "修改 PCB"
        self.description = "创建圆形区域\n或圆形禁止布线区"
        self.icon_file_name = os.path.join(os.path.dirname(__file__), "./round_keepout_area.png")
        self.show_toolbar_button = True

    def build(self, center_x, center_y, radius, keepout, edge_count):
        sp = pcbnew.SHAPE_POLY_SET()
        sp.NewOutline()
        cnt = int(edge_count)
        for i in range(cnt):
            x = int(center_x + radius * cos(i * 2 * pi / cnt))
            y = int(center_y + radius * sin(i * 2 * pi / cnt))
            sp.Append(x, y)
        # sp.OutlineCount()
        sp.thisown = 0
        # zone = pcbnew.PCB_ZONE(self.pcb)
        zone = pcbnew.ZONE(self.pcb)
        zone.SetOutline(sp)
        zone.SetLayer(pcbnew.F_Cu)
        zone.SetIsRuleArea(False)
        zone.SetDoNotAllowCopperPour(not keepout)
        zone.SetDoNotAllowFootprints(keepout)
        zone.SetDoNotAllowPads(keepout)
        zone.SetDoNotAllowTracks(keepout)
        zone.SetDoNotAllowVias(keepout)

        zone.thisown = 0
        self.pcb.Add(zone)

    def Warn(self, message, caption='Warning!'):
        dlg = wx.MessageDialog(
            None, message, caption, wx.OK | wx.ICON_WARNING)
        dlg.ShowModal()
        dlg.Destroy()

    def CheckInput(self, value, data):
        val = None
        try:
            val = float(value)
            if val == 0:
                raise Exception("Invalid")
        except:
            self.Warn(
                "%s 参数无效：必须为正数" % data)
            val = None
        return val

    def Run(self):
        self.pcb = pcbnew.GetBoard()
        a = CircularZoneDlg(None)
        x = 0
        y = 0
        reference = None
        for module in self.pcb.GetFootprints():
            if module.IsSelected():
                x = module.GetPosition().x
                y = module.GetPosition().y
                reference = module.GetReference()
                break
        if reference is None:
            a.m_comment.SetLabel("未选择参考器件：将使用原点作为圆心")
        else:
            a.m_comment.SetLabel("使用 %s 作为位置参考" % reference)

        a.m_radiusMM.SetValue("10")
        modal_result = a.ShowModal()

        segment = self.CheckInput(
            a.m_textCtrl_seg.GetValue(), "分段数量")
        radius = self.CheckInput(a.m_radiusMM.GetValue(), "半径")

        if segment is not None and radius is not None:
            if modal_result == wx.ID_OK:
                self.build(x, y, pcbnew.FromMM(
                    radius), a.m_radio_out.GetValue(), segment)
            else:
                None  # Cancel
        else:
            None  # Invalid input
        a.Destroy()
